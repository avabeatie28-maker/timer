# 30-Minute Quiz Timer

A web app that tests you every 30 minutes with custom questions!

## Features
- ⏰ Automatic testing every 30 minutes
- 🔔 Push notifications
- ➕ Custom questions
- 📊 Test history tracking
- 💾 Saves your data locally
- 📱 Works as an iPhone/Android app

## How to Deploy (FREE)

### Option 1: Netlify Drop (Easiest - 2 minutes)
1. Go to https://app.netlify.com/drop
2. Drag and drop the entire `quiz-timer-app` folder
3. Done! You'll get a URL like `https://yourapp.netlify.app`

### Option 2: Vercel (Easy - 3 minutes)
1. Go to https://vercel.com/new
2. Sign up with GitHub (free)
3. Click "Add New" → "Project"
4. Upload the folder or connect your GitHub repo
5. Click "Deploy"
6. Done! You'll get a URL like `https://yourapp.vercel.app`

### Option 3: GitHub Pages (Free forever)
1. Go to https://github.com
2. Create a new repository called `quiz-timer`
3. Upload all files from this folder
4. Go to Settings → Pages
5. Set Source to "main branch"
6. Your site will be at `https://yourusername.github.io/quiz-timer`

## How to Add to iPhone Home Screen

1. Open the website in Safari
2. Tap the Share button (square with arrow)
3. Scroll down and tap "Add to Home Screen"
4. Name it "Quiz Timer"
5. Tap "Add"
6. When prompted, allow notifications!

Now it works like a real app! 📱

## Files Included
- `index.html` - Main app file
- `manifest.json` - PWA configuration
- `service-worker.js` - Offline support
- `icon.svg` - App icon

## Tips
- Your questions are saved automatically
- Keep the app open in the background for timely notifications
- The timer pauses when you close the app (by design)
